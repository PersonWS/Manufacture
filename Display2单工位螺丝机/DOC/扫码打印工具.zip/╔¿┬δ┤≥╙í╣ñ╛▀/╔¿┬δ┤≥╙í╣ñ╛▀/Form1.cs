﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Drawing.Printing;
using System.Threading;
using System.Text.RegularExpressions;
using System.Management;
using System.IO;
using Trace.Common.UnicodeToZPL;

namespace 扫码打印工具
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbb_PrintNum.SelectedIndex = 0;
            cbb_Type.SelectedIndex = 0;
            cbb_DevType.SelectedIndex = 0;
        }
        
        private void txtPath_DragEnter(object sender, DragEventArgs e)
        {
            string temp = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            if (temp.Contains(".Mdb"))
                txtPath.Text = temp;
        }

        private void BTN_SetLogPath_Click(object sender, EventArgs e)
        {
            //创建打开文件窗口实例
            OpenFileDialog load_file = new OpenFileDialog();

            load_file.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            load_file.Filter = "Mdb|*.Mdb";

            if (load_file.ShowDialog() != DialogResult.Cancel)
            {
                //og文件绝对路径
                txtPath.Text = load_file.FileName;
            }
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            string printername = ConfigurationManager.AppSettings["PrinterName"].ToString();
            if (!CheckPrinter(printername))
            {
                MessageBox.Show("电脑中找不到名称为：" + printername + "的打印机");
                return;
            }
            if (!CheckPrinterInLine(printername))
            {
                MessageBox.Show(printername + "打印机未连接");
                return;
            }


            ZebraPrintHelper.PrinterProgrammingLanguage = ProgrammingLanguage.ZPL;
            ZebraPrintHelper.PrinterName = printername;
            ZebraPrintHelper.PrinterType = DeviceType.DRV;

            string mac_temp = txtMAC.Text.Replace("-", "");
            string pin_temp = txtPIN.Text;

            if (!Regex.IsMatch(mac_temp, "^[A-Fa-f0-9]{16}$") || !Regex.IsMatch(pin_temp, "^[0-9]{12}$"))
            {
                MessageBox.Show("MAC地址或PIN数据格式不正确，不能打印");
                return;
            }


            for (int i = 0; i <= cbb_PrintNum.SelectedIndex; i++)
            {
                StringBuilder sb = new StringBuilder();
                //sb.Append("^XA^CFD");
                //sb.Append("^POI");
                //sb.Append("^LH560,10");
                //sb.Append("^FO40,25^BY2,2.0,55^BAN,60,N,N,N^FD" + mac_temp + "^FS");
                //sb.Append("^FO40,90^ABN,22,14^FDMAC:" + mac_temp + "^FS");
                //sb.Append("^FO40,120^BY2,2.0,50^BAN,60,N,N,N^FD" + pin_temp + "^FS");
                //sb.Append("^FO40,185^ABN,22,14^FDPIN:" + pin_temp + "^FS");
                //sb.Append("^XZ");

                if (cbb_Type.SelectedIndex == 0)
                {
                    sb.Append("^XA");
                    sb.Append("^LH560,10");
                    sb.Append("^FO40,157^BY2,2.0,55^BAN,60,N,N,N^FD" + mac_temp + "^FS");
                    sb.Append("^FO40,125^FR^ABI,22,14^FDMAC:" + mac_temp + "^FS");
                    sb.Append("^FO115,57^BY2,2.0,55^BAN,60,N,N,N^FD" + pin_temp + "^FS");
                    sb.Append("^FO115,20^FR^ABI,22,14^FDPIN:" + pin_temp + "^FS");
                    sb.Append("^XZ");
                    //sb.Append("^XA");
                    //sb.Append("^POI");
                    //sb.Append("^LH560,10");
                    //sb.Append("^FO40,25^BY2,2.0,55^BAN,60,N,N,N^FD" + mac_temp + "^FS");
                    //sb.Append("^FO40,90^ABN,22,14^FDMAC:" + mac_temp + "^FS");
                    //sb.Append("^FO40,120^BY2,2.0,50^BAN,60,N,N,N^FD" + pin_temp + "^FS");
                    //sb.Append("^FO40,185^ABN,22,14^FDPIN:" + pin_temp + "^FS");
                    //sb.Append("^XZ");
                }
                else
                {
                    sb.Append("^XA");
                    sb.Append("^LH10,10");
                    sb.Append("^FO70,50^BY5,3.0,150^BAN,150,N,N,N^FD" + pin_temp + "^FS");
                    Font myfont = new Font("宋体", 32);
                    string pin = UnicodeToZPL.UnCompressZPL("PIN：" + pin_temp, "mypic0", myfont, TextDirection.零度);
                    string temp1 =  UnicodeToZPL.UnCompressZPL("产品名称：" + cbb_DevType.Text, "mypic1", myfont, TextDirection.零度);
                    string temp2 = UnicodeToZPL.UnCompressZPL("产品型号：FDWXSJZD02", "mypic2", myfont, TextDirection.零度);
                    string temp3 = UnicodeToZPL.UnCompressZPL("生产厂商：南京富岛信息工程有限公司", "mypic3", myfont, TextDirection.零度);
                    sb.Append("^FO220,220" + pin + "^FS");
                    sb.Append("^FO50,320" + temp1 + "^FS");
                    sb.Append("^FO50,400" + temp2 + "^FS");
                    sb.Append("^FO50,480" + temp3 + "^FS");
                    sb.Append("^XZ");
                }
                ZebraPrintHelper.PrintCommand(sb.ToString());
                Thread.Sleep(200);
            }

            txtIn.Clear();
            txtMAC.Clear();
            txtPIN.Clear();
        }

        /// <summary>
        /// 检查打印机是否存在
        /// </summary>
        private bool CheckPrinter(string printername)
        {
            foreach (string sPrint in PrinterSettings.InstalledPrinters)//获取所有打印机名称
            {
                if (printername == sPrint)
                    return true;
            }
            return false;   
        }

        /// <summary>
        /// 检查打印机是否在线
        /// </summary>
        private bool CheckPrinterInLine(string printername)
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Printer");

            foreach (ManagementObject printer in searcher.Get())
            {
                if (printer["Name"].ToString() == printername && printer["WorkOffline"].ToString().ToLower().Equals("false"))
                    return true;
            }
            return false;
        }

        private void txtIn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtMAC.Clear();
                txtPIN.Clear();

                if (!File.Exists(txtPath.Text))
                {
                    MessageBox.Show("数据库文件不存在！");
                    return;
                }

                AccessHelper dbhelp = new AccessHelper(txtPath.Text);

                string strSql = "";
                if (Regex.IsMatch(txtIn.Text, "^[A-Fa-f0-9]{16}$"))
                {
                    string temp = txtIn.Text;
                    for (int i = 7; i > 0; i--)
                    {
                        temp = temp.Insert(2 * i, "-");
                    }
                    temp = temp.ToUpper();
                    strSql = "select * from pinmac where mac='" + temp +"'";
                }
                else if (Regex.IsMatch(txtIn.Text, "^[0-9]{12}$"))
                    strSql = "select * from pinmac where pin='" + txtIn.Text + "'";
                else
                {
                    MessageBox.Show("输入MAC地址或PIN地址不正确！");
                    return;
                }

                DataSet ds = dbhelp.dataSet(strSql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtPIN.Text = ds.Tables[0].Rows[0]["pin"].ToString();
                    txtMAC.Text = ds.Tables[0].Rows[0]["mac"].ToString();
                }
                else
                {
                    MessageBox.Show("数据库中未找到设备数据");
                    return;
                }
            }
        }

        private void cbb_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbb_Type.SelectedIndex == 0)
            {
                cbb_DevType.Visible = false;
                lb_DevType.Visible = false;
            }
            else
            {
                cbb_DevType.Visible = true;
                lb_DevType.Visible = true;
            }
        }
    }
}
