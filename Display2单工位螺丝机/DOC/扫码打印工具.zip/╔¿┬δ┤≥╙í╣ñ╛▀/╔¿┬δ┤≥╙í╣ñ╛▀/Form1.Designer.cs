﻿namespace 扫码打印工具
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_SetLogPath = new System.Windows.Forms.Button();
            this.btn_Print = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.cbb_PrintNum = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPIN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMAC = new System.Windows.Forms.TextBox();
            this.txtIn = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbb_DevType = new System.Windows.Forms.ComboBox();
            this.lb_DevType = new System.Windows.Forms.Label();
            this.cbb_Type = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtPath
            // 
            this.txtPath.AllowDrop = true;
            this.txtPath.Location = new System.Drawing.Point(21, 35);
            this.txtPath.Multiline = true;
            this.txtPath.Name = "txtPath";
            this.txtPath.ReadOnly = true;
            this.txtPath.Size = new System.Drawing.Size(303, 59);
            this.txtPath.TabIndex = 6;
            this.txtPath.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtPath_DragEnter);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(19, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "当前数据库文件路径(可直接将文件直接拖入框中)：";
            // 
            // BTN_SetLogPath
            // 
            this.BTN_SetLogPath.Location = new System.Drawing.Point(403, 35);
            this.BTN_SetLogPath.Name = "BTN_SetLogPath";
            this.BTN_SetLogPath.Size = new System.Drawing.Size(147, 38);
            this.BTN_SetLogPath.TabIndex = 4;
            this.BTN_SetLogPath.Text = "设置数据库文件路径";
            this.BTN_SetLogPath.UseVisualStyleBackColor = true;
            this.BTN_SetLogPath.Click += new System.EventHandler(this.BTN_SetLogPath_Click);
            // 
            // btn_Print
            // 
            this.btn_Print.Location = new System.Drawing.Point(416, 20);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(134, 51);
            this.btn_Print.TabIndex = 9;
            this.btn_Print.Text = "打印";
            this.btn_Print.UseVisualStyleBackColor = true;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 8;
            this.label13.Text = "打印张数";
            // 
            // cbb_PrintNum
            // 
            this.cbb_PrintNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_PrintNum.FormattingEnabled = true;
            this.cbb_PrintNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cbb_PrintNum.Location = new System.Drawing.Point(73, 36);
            this.cbb_PrintNum.Name = "cbb_PrintNum";
            this.cbb_PrintNum.Size = new System.Drawing.Size(89, 20);
            this.cbb_PrintNum.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BTN_SetLogPath);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtPath);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(577, 100);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据库路径";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtPIN);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtMAC);
            this.groupBox2.Controls.Add(this.txtIn);
            this.groupBox2.Location = new System.Drawing.Point(3, 109);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(573, 115);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "扫码输入";
            // 
            // txtPIN
            // 
            this.txtPIN.Location = new System.Drawing.Point(403, 62);
            this.txtPIN.Name = "txtPIN";
            this.txtPIN.ReadOnly = true;
            this.txtPIN.Size = new System.Drawing.Size(147, 21);
            this.txtPIN.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(280, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "（扫MAC或PIN均可）";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "扫码输入：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(361, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "PIN：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "MAC地址：";
            // 
            // txtMAC
            // 
            this.txtMAC.Location = new System.Drawing.Point(73, 62);
            this.txtMAC.Name = "txtMAC";
            this.txtMAC.ReadOnly = true;
            this.txtMAC.Size = new System.Drawing.Size(201, 21);
            this.txtMAC.TabIndex = 0;
            // 
            // txtIn
            // 
            this.txtIn.Location = new System.Drawing.Point(72, 20);
            this.txtIn.Name = "txtIn";
            this.txtIn.Size = new System.Drawing.Size(202, 21);
            this.txtIn.TabIndex = 0;
            this.txtIn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtIn_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbb_DevType);
            this.groupBox3.Controls.Add(this.lb_DevType);
            this.groupBox3.Controls.Add(this.cbb_PrintNum);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.btn_Print);
            this.groupBox3.Location = new System.Drawing.Point(3, 230);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(573, 80);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "打印操作";
            // 
            // cbb_DevType
            // 
            this.cbb_DevType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_DevType.FormattingEnabled = true;
            this.cbb_DevType.Items.AddRange(new object[] {
            "无线数据终端",
            "无线数据终端_路由器",
            "无线数据终端_协调器"});
            this.cbb_DevType.Location = new System.Drawing.Point(232, 36);
            this.cbb_DevType.Name = "cbb_DevType";
            this.cbb_DevType.Size = new System.Drawing.Size(149, 20);
            this.cbb_DevType.TabIndex = 7;
            // 
            // lb_DevType
            // 
            this.lb_DevType.AutoSize = true;
            this.lb_DevType.Location = new System.Drawing.Point(173, 40);
            this.lb_DevType.Name = "lb_DevType";
            this.lb_DevType.Size = new System.Drawing.Size(53, 12);
            this.lb_DevType.TabIndex = 8;
            this.lb_DevType.Text = "设备类型";
            // 
            // cbb_Type
            // 
            this.cbb_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Type.FormattingEnabled = true;
            this.cbb_Type.Items.AddRange(new object[] {
            "内标签",
            "外包装标签"});
            this.cbb_Type.Location = new System.Drawing.Point(84, 10);
            this.cbb_Type.Name = "cbb_Type";
            this.cbb_Type.Size = new System.Drawing.Size(121, 20);
            this.cbb_Type.TabIndex = 12;
            this.cbb_Type.SelectedIndexChanged += new System.EventHandler(this.cbb_Type_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Location = new System.Drawing.Point(1, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(583, 317);
            this.panel1.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "条码类型：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 366);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbb_Type);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "扫码打印工具";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_SetLogPath;
        private System.Windows.Forms.Button btn_Print;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbb_PrintNum;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtPIN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMAC;
        private System.Windows.Forms.TextBox txtIn;
        private System.Windows.Forms.ComboBox cbb_Type;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbb_DevType;
        private System.Windows.Forms.Label lb_DevType;
    }
}

